import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.testobject.SelectorMethod

import com.thoughtworks.selenium.Selenium
import org.openqa.selenium.firefox.FirefoxDriver
import org.openqa.selenium.WebDriver
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium
import static org.junit.Assert.*
import java.util.regex.Pattern
import static org.apache.commons.lang3.StringUtils.join
import org.testng.asserts.SoftAssert
import com.kms.katalon.core.testdata.CSVData
import org.openqa.selenium.Keys as Keys

SoftAssert softAssertion = new SoftAssert();
WebUI.openBrowser('https://www.google.com/')
def driver = DriverFactory.getWebDriver()
String baseUrl = "https://www.google.com/"
selenium = new WebDriverBackedSelenium(driver, baseUrl)
selenium.open("http://localhost:4200/menu")
selenium.click("xpath=(.//*[normalize-space(text()) and normalize-space(.)='Menu'])[1]/preceding::li[1]")
selenium.open("http://localhost:4200/home")
selenium.click("link=Home")
selenium.click("link=Menu")
selenium.open("http://localhost:4200/menu")
selenium.click("xpath=//section[@id='beverage']/div[2]/div/div[2]/div[2]/button")
selenium.click("id=size-grande")
selenium.click("xpath=(.//*[normalize-space(text()) and normalize-space(.)='Sweet'])[1]/following::select[1]")
selenium.select("xpath=(.//*[normalize-space(text()) and normalize-space(.)='Sweet'])[1]/following::select[1]", "label=50%")
selenium.click("id=type-FRAPPE")
selenium.click("xpath=//textarea")
selenium.type("xpath=//textarea", ("-2#-""").toString())
selenium.click("xpath=//button[@type='submit']")
selenium.click("xpath=//section[@id='cake']/div[2]/div/div[2]/div[2]/button")
selenium.click("xpath=//button[@type='submit']")
selenium.click("xpath=(.//*[normalize-space(text()) and normalize-space(.)='Menu'])[1]/following::li[1]")
selenium.click("link=Boardgame")
selenium.open("http://localhost:4200/boardgame")
selenium.click("xpath=//section[@id='beverage']/div[2]/div/div/div[2]/div[2]")
selenium.click("xpath=//section[@id='beverage']/div[2]/div/div/div[2]/div[2]/button")
selenium.click("xpath=(.//*[normalize-space(text()) and normalize-space(.)='Add to cart'])[1]/following::button[1]")
selenium.open("http://localhost:4200/cart")
selenium.click("xpath=(.//*[normalize-space(text()) and normalize-space(.)='TOTAL'])[1]/following::button[1]")
selenium.click("id=upload")
selenium.type("id=upload", ("C:\\Users\\thana\\Pictures\\Screenshots\\Screenshot 2024-01-11 102530.png").toString())
selenium.click("xpath=//button[@type='submit']")

<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>angular caffe</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>bd6e0d54-b503-4d64-ae79-c644f6551325</testSuiteGuid>
   <testCaseLink>
      <guid>f13100b4-53e3-4ed2-8a95-440365ae8518</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/angular caffe/Test the usability of the website in the customer section</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
    